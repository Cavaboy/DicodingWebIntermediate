// Simple Not Found page renderer
export default function renderNotFoundPage() {
    return `
    <section class="container">
      <h2>404 - Not Found</h2>
      <p>Halaman yang Anda cari tidak ditemukan.</p>
    </section>
  `;
}
