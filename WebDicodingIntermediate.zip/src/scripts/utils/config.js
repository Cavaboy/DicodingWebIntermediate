const API_CONFIG = {
    BASE_URL: 'https://story-api.dicoding.dev/v1',
    GET_ALL_STORIES: 'https://story-api.dicoding.dev/v1/stories',
    ADD_NEW_STORY: 'https://story-api.dicoding.dev/v1/stories',
};

export default API_CONFIG;