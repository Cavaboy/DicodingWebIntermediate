import StoryAPI from '../data/api.js';

const BasePresenter = {
    isAuthenticated() {
        return !!StoryAPI.getToken();
    },

    redirectToLogin() {
        window.location.hash = '/login';
    },

    navigateTo(path) {
        window.location.hash = path;
    }
};

export default BasePresenter;
