import StoryAPI from '../../data/api.js';

const RegisterPresenter = {
    async register(name, email, password) {
        return await StoryAPI.register(name, email, password);
    }
};

export default RegisterPresenter;
