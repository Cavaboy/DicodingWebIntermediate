import RegisterPresenter from './register-presenter.js';

const RegisterPage = {
  async render() {
    return `
      <main id="main-content">
        <section>
          <h2>Register</h2>
          <form id="register-form">
            <div>
              <label for="name">Name</label>
              <input type="text" id="name" name="name" required />
            </div>
            <div>
              <label for="email">Email</label>
              <input type="email" id="email" name="email" required />
            </div>
            <div>
              <label for="password">Password</label>
              <input type="password" id="password" name="password" required minlength="8" />
            </div>
            <button type="submit">Register</button>
          </form>
          <div id="register-message"></div>
        </section>
      </main>
    `;
  },

  async afterRender() {
    const form = document.getElementById('register-form');
    const messageDiv = document.getElementById('register-message');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const name = form.name.value;
      const email = form.email.value;
      const password = form.password.value;
      messageDiv.textContent = 'Registering...';
      try {
        await RegisterPresenter.register(name, email, password);
        messageDiv.textContent = 'Register berhasil! Silakan login.';
        setTimeout(() => {
          window.location.hash = '/login';
        }, 1000);
      } catch (err) {
        messageDiv.textContent = 'Register gagal: ' + err.message;
      }
    });
  }
};

export default RegisterPage;
