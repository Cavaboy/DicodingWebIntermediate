import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import HomePresenter from './home-presenter.js';

const HomePage = {
  async render() {
    return `
      <main id="main-content">
        <section>
          <h2>Daftar Cerita</h2>
          <div id="stories-container" class="stories" tabindex="-1"></div>
        </section>
        <section>
          <h2>Peta Lokasi Cerita</h2>
          <div id="map" style="height: 400px;"></div>
        </section>
        <button class="add-story-btn" aria-label="Tambah Cerita" onclick="window.location.hash='/add-story'">+</button>
      </main>
      <footer>
        <p>&copy; 2025 Dicoding Story App</p>
      </footer>
    `;
  },

  async afterRender() {
    const container = document.getElementById('stories-container');
    container.innerHTML = '<p>Loading stories...</p>';
    try {
      const stories = await HomePresenter.getStories();
      container.innerHTML = '';
      stories.forEach(story => {
        const storyElem = document.createElement('div');
        storyElem.className = 'story-item';
        storyElem.innerHTML = `
          <img src="${story.photoUrl}" alt="Foto cerita oleh ${story.name}" loading="lazy" />
          <h4>${story.name}</h4>
          <p>${story.description}</p>
          <p><small>${new Date(story.createdAt).toLocaleString()}</small></p>
        `;
        container.appendChild(storyElem);
      });
      this._initializeMap(stories);
    } catch (error) {
      container.innerHTML = `<p class="error">${error.message}</p>`;
    }
  },

  _initializeMap(stories) {
    const mapDiv = document.getElementById('map');
    if (!mapDiv) return;
    const map = L.map(mapDiv).setView([-2.5, 118], 5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    stories.forEach(story => {
      if (story.lat && story.lon) {
        const marker = L.marker([story.lat, story.lon]).addTo(map);
        marker.bindPopup(`<b>${story.name}</b><br>${story.description}`);
      }
    });
  }
};

export default HomePage;
