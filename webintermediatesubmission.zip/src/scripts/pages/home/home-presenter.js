import StoryAPI from '../../data/api.js';

const HomePresenter = {
    async getStories() {
        return await StoryAPI.getAllStories();
    }
};

export default HomePresenter;
