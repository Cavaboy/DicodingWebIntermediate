import StoryAPI from '../../data/api.js';

const LoginPresenter = {
    async login(email, password) {
        return await StoryAPI.login(email, password);
    },

    isLoggedIn() {
        return !!StoryAPI.getToken();
    }
};

export default LoginPresenter;
