import LoginPresenter from './login-presenter.js';

const LoginPage = {
  async render() {
    return `
      <main id="main-content">
        <section>
          <h2>Login</h2>
          <form id="login-form">
            <div>
              <label for="email">Email</label>
              <input type="email" id="email" name="email" required />
            </div>
            <div>
              <label for="password">Password</label>
              <input type="password" id="password" name="password" required minlength="8" />
            </div>
            <button type="submit">Login</button>
          </form>
          <div id="login-message"></div>
        </section>
      </main>
    `;
  },

  async afterRender() {
    const form = document.getElementById('login-form');
    const messageDiv = document.getElementById('login-message');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email = form.email.value;
      const password = form.password.value;
      messageDiv.textContent = 'Logging in...';
      try {
        await LoginPresenter.login(email, password);
        messageDiv.textContent = 'Login berhasil!';
        setTimeout(() => {
          window.location.hash = '/';
        }, 1000);
      } catch (err) {
        messageDiv.textContent = 'Login gagal: ' + err.message;
      }
    });
  }
};

export default LoginPage;
